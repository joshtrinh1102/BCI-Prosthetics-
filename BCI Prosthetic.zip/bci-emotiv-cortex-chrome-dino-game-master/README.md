# Brain-computer interface with Emotiv Cortex API to control the T-Rex in Chrome game

A quarantine weekend project... experimenting with Emotiv Cortex API to control the dinosaur in chrome (no-internet) game with a mental command.

It's definitely hard and demands a lot of concentration and training.

Best results achieved with just one command trained, not several, and always complementing training with neutral.

A small video, and yes, cheats were in place ;-)

<a href="http://www.youtube.com/watch?feature=player_embedded&v=VrekuGAf__M" target="_blank"><img src="http://img.youtube.com/vi/VrekuGAf__M/0.jpg" alt="IMAGE ALT TEXT HERE" width="240" height="180" border="10" /></a>

